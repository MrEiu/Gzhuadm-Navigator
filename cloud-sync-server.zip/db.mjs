import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import { fileURLToPath } from 'url';
import { commitDataToGit, initGitRepo, rollbackGitCommit } from './gitManager.mjs';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const dataDir = path.join(__dirname, 'data');
const dbFilePath = path.join(dataDir, 'cloud_data_v2.json');
const metaFilePath = path.join(dataDir, 'cloud_meta_v2.json');
const snapshotsFilePath = path.join(dataDir, 'cloud_snapshots.json');

if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
}

// Compute hash helper
const computeItemHash = (item) => {
    if (!item) return '';
    const tableText = item.tableData?.rows ? JSON.stringify(item.tableData.rows) : '';
    const raw = `${(item.title || '').trim()}|${(item.category || '').trim()}|${(item.content || '').trim()}|${item.targetAgent || 'all'}|${tableText}`;
    return crypto.createHash('sha256').update(raw).digest('hex').slice(0, 24);
};

// 8-Domain In-Memory Database
let cloudStore = {
    rag: [],            // Array of RAG items
    agents: {},         // Multi-Agent Roster Object
    campusMap: [],      // Campus Map Location Pins Array
    bubble: {},         // Bubble UI Settings Object
    memes: [],          // GIF Memes & Stickers Array
    tts: {},            // TTS Configuration Object
    userProfiles: {},   // User Profiles Object
    chatSessions: []    // Chat Sessions Array
};

// Domain-level metadata & Hash Indexes
let domainMeta = {
    rag: { lastUpdatedAt: null, totalCount: 0 },
    agents: { lastUpdatedAt: null, hash: '' },
    campusMap: { lastUpdatedAt: null, totalCount: 0 },
    bubble: { lastUpdatedAt: null, hash: '' },
    memes: { lastUpdatedAt: null, totalCount: 0 },
    tts: { lastUpdatedAt: null, hash: '' },
    userProfiles: { lastUpdatedAt: null, totalCount: 0 },
    chatSessions: { lastUpdatedAt: null, totalCount: 0 }
};

let arrayHashIndexes = {
    rag: new Set(),
    campusMap: new Set(),
    memes: new Set(),
    userProfiles: new Set(),
    chatSessions: new Set()
};

let serverStats = {
    totalPushes: 0,
    totalPulls: 0,
    serverStartedAt: new Date().toISOString(),
    lastUpdatedAt: new Date().toISOString()
};

// Snapshot History Timeline
let cloudSnapshots = [];

// Initialize DB from disk
export const initCloudDb = async () => {
    if (fs.existsSync(dbFilePath)) {
        try {
            const raw = fs.readFileSync(dbFilePath, 'utf8');
            cloudStore = { ...cloudStore, ...JSON.parse(raw) };
        } catch (e) {
            console.error('Failed to parse cloud_data_v2.json:', e.message);
        }
    } else {
        saveToDisk();
    }

    if (fs.existsSync(metaFilePath)) {
        try {
            const parsedMeta = JSON.parse(fs.readFileSync(metaFilePath, 'utf8'));
            serverStats = { ...serverStats, ...parsedMeta.stats };
            domainMeta = { ...domainMeta, ...parsedMeta.domains };
        } catch { }
    }

    if (fs.existsSync(snapshotsFilePath)) {
        try {
            cloudSnapshots = JSON.parse(fs.readFileSync(snapshotsFilePath, 'utf8'));
        } catch {
            cloudSnapshots = [];
        }
    }

    // Auto-seed from workspace ../data/ for any domain that is currently empty
    const parentDataDir = path.join(__dirname, '..', 'data');
    const parentMapFile = path.join(__dirname, '..', 'campus_navigation.map');
    let hasSeededAny = false;

    if (fs.existsSync(parentDataDir)) {
        // 1. RAG Knowledge
        if (cloudStore.rag.length === 0) {
            const ragPath = path.join(parentDataDir, 'rag_knowledge.json');
            if (fs.existsSync(ragPath)) {
                try { cloudStore.rag = JSON.parse(fs.readFileSync(ragPath, 'utf8')); hasSeededAny = true; } catch { }
            }
        }

        // 2. Agents
        if (!Object.keys(cloudStore.agents || {}).length) {
            const agentsPath = path.join(parentDataDir, 'agents_config.json');
            if (fs.existsSync(agentsPath)) {
                try { cloudStore.agents = JSON.parse(fs.readFileSync(agentsPath, 'utf8')); hasSeededAny = true; } catch { }
            }
        }

        // 3. Campus Map
        if (cloudStore.campusMap.length === 0 && fs.existsSync(parentMapFile)) {
            try {
                const mapRaw = JSON.parse(fs.readFileSync(parentMapFile, 'utf8'));
                cloudStore.campusMap = Array.isArray(mapRaw) ? mapRaw : (mapRaw.locations || []);
                hasSeededAny = true;
            } catch { }
        }

        // 4. Bubble
        if (!Object.keys(cloudStore.bubble || {}).length) {
            const bubblePath = path.join(parentDataDir, 'bubble_settings.json');
            if (fs.existsSync(bubblePath)) {
                try { cloudStore.bubble = JSON.parse(fs.readFileSync(bubblePath, 'utf8')); } catch { }
            } else {
                cloudStore.bubble = { themeId: 'antdesign_filled', borderRadius: 20, accentBarWidth: 0, showTail: false, showActions: true, showThinkingBox: true };
            }
            hasSeededAny = true;
        }

        // 5. Memes (12 default GIFs)
        if (cloudStore.memes.length === 0) {
            cloudStore.memes = [
                { id: 'meme_cat_eat', title: '猫猫炫饭', url: 'https://media.giphy.com/media/unQ3IJU2RG7DO/giphy.gif', type: 'gif' },
                { id: 'meme_dog_cheer', title: '柴犬点赞', url: 'https://media.giphy.com/media/3o7abKhOpu0NwenH3O/giphy.gif', type: 'gif' },
                { id: 'meme_study', title: '疯狂复习', url: 'https://media.giphy.com/media/3o7btPCcdNniyf0ArS/giphy.gif', type: 'gif' },
                { id: 'meme_toast', title: '干杯庆祝', url: 'https://media.giphy.com/media/g9582DNuQppxC/giphy.gif', type: 'gif' },
                { id: 'meme_heart', title: '比心点赞', url: 'https://media.giphy.com/media/26FLdmIp6wJr91JAI/giphy.gif', type: 'gif' },
                { id: 'meme_cry', title: '嚎啕大哭', url: 'https://media.giphy.com/media/d2lcHJTG5Tscg/giphy.gif', type: 'gif' },
                { id: 'meme_shock', title: '震惊目瞪口呆', url: 'https://media.giphy.com/media/5VKbvrjxpVJCM/giphy.gif', type: 'gif' },
                { id: 'meme_running', title: '赶早八狂奔', url: 'https://media.giphy.com/media/3o7ZetIsjgoYKlVe9y/giphy.gif', type: 'gif' },
                { id: 'meme_nod', title: '频频点头', url: 'https://media.giphy.com/media/10Jpr9KSaXLchW/giphy.gif', type: 'gif' },
                { id: 'meme_confused', title: '满头问号', url: 'https://media.giphy.com/media/3o7TKTDnUxE0g2fSE8/giphy.gif', type: 'gif' },
                { id: 'meme_bye', title: '挥手再见', url: 'https://media.giphy.com/media/m9eG1qVjvNsfK/giphy.gif', type: 'gif' },
                { id: 'meme_party', title: '录取庆祝', url: 'https://media.giphy.com/media/artj92V8o75VPL7AeQ/giphy.gif', type: 'gif' }
            ];
            hasSeededAny = true;
        }

        // 6. TTS
        if (!Object.keys(cloudStore.tts || {}).length) {
            const ttsPath = path.join(parentDataDir, 'tts_config.json');
            if (fs.existsSync(ttsPath)) {
                try { cloudStore.tts = JSON.parse(fs.readFileSync(ttsPath, 'utf8')); } catch { }
            } else {
                cloudStore.tts = { engine: 'msedge', defaultVoice: 'zh-CN-XiaoyiNeural', rate: 1.0, pitch: 1.0 };
            }
            hasSeededAny = true;
        }

        // 7. Profiles & Sessions
        if (!Object.keys(cloudStore.userProfiles || {}).length) {
            const profPath = path.join(parentDataDir, 'user_profiles.json');
            if (fs.existsSync(profPath)) {
                try { cloudStore.userProfiles = JSON.parse(fs.readFileSync(profPath, 'utf8')); hasSeededAny = true; } catch { }
            }
        }

        if (cloudStore.chatSessions.length === 0) {
            const sessPath = path.join(parentDataDir, 'user_sessions.json');
            if (fs.existsSync(sessPath)) {
                try { cloudStore.chatSessions = JSON.parse(fs.readFileSync(sessPath, 'utf8')); hasSeededAny = true; } catch { }
            }
        }

        if (hasSeededAny && cloudSnapshots.length === 0) {
            const now = new Date();
            cloudSnapshots = [{
                id: 'snap_init_' + Date.now().toString(36),
                timestamp: now.toISOString(),
                timeStr: now.toLocaleDateString('zh-CN', { month: '2-digit', day: '2-digit' }) + ' ' + now.toLocaleTimeString('zh-CN', { hour12: false, hour: '2-digit', minute: '2-digit' }),
                author: '系统基准植入',
                summary: '初始化 8 大领域数据基准 (含 128 条招生知识库、5位智能体、校园地图)',
                updatedDomains: ['招生知识库', '5位智能体人设', '手绘校园地图', '气泡UI皮肤', '动图表情包', 'TTS语音配置']
            }];
        }

        if (hasSeededAny) {
            saveToDisk();
        }
    }

    rebuildIndexes();

    // Async background Git init and sync
    try {
        await initGitRepo();
        await commitDataToGit(cloudStore, '系统自动归档', '同步当前云端全量 8 大领域数据基准');
    } catch (e) {
        console.warn('Background Git repo note:', e.message);
    }

    console.log(`📦 [Cloud DB Ready] 8-Domain High-Performance Cloud Database Initialized:`);
    console.log(`   - 📚 RAG Knowledge:   ${cloudStore.rag.length} items`);
    console.log(`   - 👥 Agents Roster:   ${Object.keys(cloudStore.agents || {}).length} agents`);
    console.log(`   - 🗺️ Campus Map:      ${cloudStore.campusMap.length} landmarks`);
    console.log(`   - 🎨 Bubble Settings: ${Object.keys(cloudStore.bubble || {}).length ? 'Active' : 'Default'}`);
    console.log(`   - 🎬 Memes & Stickers:${cloudStore.memes.length} items`);
    console.log(`   - 🎙️ TTS Config:      ${Object.keys(cloudStore.tts || {}).length ? 'Active' : 'Default'}`);
    console.log(`   - 👤 User Profiles:   ${Object.keys(cloudStore.userProfiles || {}).length} profiles`);
    console.log(`   - 💬 Chat Sessions:   ${Array.isArray(cloudStore.chatSessions) ? cloudStore.chatSessions.length : Object.keys(cloudStore.chatSessions || {}).length} sessions`);
};

export const rebuildIndexes = () => {
    arrayHashIndexes.rag.clear();
    for (const item of (cloudStore.rag || [])) {
        if (item.hash) arrayHashIndexes.rag.add(item.hash);
    }

    arrayHashIndexes.campusMap.clear();
    for (const item of (cloudStore.campusMap || [])) {
        if (item.hash) arrayHashIndexes.campusMap.add(item.hash);
    }

    arrayHashIndexes.memes.clear();
    for (const item of (cloudStore.memes || [])) {
        if (item.hash) arrayHashIndexes.memes.add(item.hash);
    }

    arrayHashIndexes.userProfiles.clear();
    if (Array.isArray(cloudStore.userProfiles)) {
        for (const item of cloudStore.userProfiles) {
            if (item.hash) arrayHashIndexes.userProfiles.add(item.hash);
        }
    }

    arrayHashIndexes.chatSessions.clear();
    if (Array.isArray(cloudStore.chatSessions)) {
        for (const item of cloudStore.chatSessions) {
            if (item.hash) arrayHashIndexes.chatSessions.add(item.hash);
        }
    }

    domainMeta.rag.totalCount = cloudStore.rag.length;
    domainMeta.campusMap.totalCount = cloudStore.campusMap.length;
    domainMeta.memes.totalCount = cloudStore.memes.length;
    domainMeta.chatSessions.totalCount = Array.isArray(cloudStore.chatSessions)
        ? cloudStore.chatSessions.length
        : Object.values(cloudStore.chatSessions || {}).reduce((acc, curr) => acc + (Array.isArray(curr) ? curr.length : 0), 0);
};

const saveToDisk = () => {
    try {
        fs.writeFileSync(dbFilePath, JSON.stringify(cloudStore, null, 2), 'utf8');
        fs.writeFileSync(metaFilePath, JSON.stringify({ stats: serverStats, domains: domainMeta }, null, 2), 'utf8');
        fs.writeFileSync(snapshotsFilePath, JSON.stringify(cloudSnapshots.slice(0, 100), null, 2), 'utf8');
    } catch (e) {
        console.error('Error saving cloud DB to disk:', e);
    }
};

// 1. Check Hashes across 8 Domains
export const checkMultiDomainHashes = (clientHashes = {}) => {
    const missing = {
        rag: [],
        agents: false,
        campusMap: [],
        bubble: false,
        memes: [],
        tts: false,
        userProfiles: false,
        chatSessions: Array.isArray(clientHashes.chatSessions) ? [] : false
    };

    if (Array.isArray(clientHashes.rag)) {
        missing.rag = clientHashes.rag.filter(h => !arrayHashIndexes.rag.has(h));
    }
    if (Array.isArray(clientHashes.campusMap)) {
        missing.campusMap = clientHashes.campusMap.filter(h => !arrayHashIndexes.campusMap.has(h));
    }
    if (Array.isArray(clientHashes.memes)) {
        missing.memes = clientHashes.memes.filter(h => !arrayHashIndexes.memes.has(h));
    }
    if (Array.isArray(clientHashes.chatSessions)) {
        missing.chatSessions = clientHashes.chatSessions.filter(h => !arrayHashIndexes.chatSessions.has(h));
    } else if (clientHashes.chatSessions) {
        missing.chatSessions = clientHashes.chatSessions !== domainMeta.chatSessions.hash;
    }

    if (clientHashes.agents) {
        missing.agents = clientHashes.agents !== domainMeta.agents.hash || !Object.keys(cloudStore.agents || {}).length;
    }
    if (clientHashes.bubble) {
        missing.bubble = clientHashes.bubble !== domainMeta.bubble.hash || !Object.keys(cloudStore.bubble || {}).length;
    }
    if (clientHashes.tts) {
        missing.tts = clientHashes.tts !== domainMeta.tts.hash || !Object.keys(cloudStore.tts || {}).length;
    }
    if (clientHashes.userProfiles) {
        missing.userProfiles = clientHashes.userProfiles !== domainMeta.userProfiles.hash;
    }

    return missing;
};

// 2. Ingest / Push Multi-Domain Data
export const upsertMultiDomainData = (payload = {}, clientHashes = {}, author = '管理员', summary = '') => {
    const now = new Date();
    const nowIso = now.toISOString();
    const timeStr = now.toLocaleDateString('zh-CN', { month: '2-digit', day: '2-digit' }) + ' ' + now.toLocaleTimeString('zh-CN', { hour12: false, hour: '2-digit', minute: '2-digit' });

    const result = {
        rag: { added: 0, updated: 0 },
        agents: false,
        campusMap: { added: 0, updated: 0 },
        bubble: false,
        memes: { added: 0, updated: 0 },
        tts: false,
        userProfiles: false,
        chatSessions: false
    };

    const updatedDomains = [];

    // Domain 1: RAG
    if (Array.isArray(payload.rag) && payload.rag.length > 0) {
        for (const item of payload.rag) {
            if (!item || !item.id) continue;
            const existingIdx = cloudStore.rag.findIndex(k => k.id === item.id || (item.hash && k.hash === item.hash));
            const formatted = { ...item, updatedAt: item.updatedAt || nowIso, cloudReceivedAt: nowIso };
            if (existingIdx >= 0) {
                cloudStore.rag[existingIdx] = formatted;
                result.rag.updated++;
            } else {
                cloudStore.rag.unshift(formatted);
                result.rag.added++;
            }
        }
        domainMeta.rag.lastUpdatedAt = nowIso;
        updatedDomains.push('招生知识库');
    }

    // Domain 2: Agents
    if (payload.agents && typeof payload.agents === 'object' && Object.keys(payload.agents).length > 0) {
        cloudStore.agents = { ...payload.agents };
        domainMeta.agents.hash = clientHashes.agents || '';
        domainMeta.agents.lastUpdatedAt = nowIso;
        result.agents = true;
        updatedDomains.push('5位智能体人设');
    }

    // Domain 3: Campus Map
    if (Array.isArray(payload.campusMap) && payload.campusMap.length > 0) {
        for (const item of payload.campusMap) {
            if (!item || !item.id) continue;
            const existingIdx = cloudStore.campusMap.findIndex(k => k.id === item.id || (item.hash && k.hash === item.hash));
            const formatted = { ...item, updatedAt: item.updatedAt || nowIso, cloudReceivedAt: nowIso };
            if (existingIdx >= 0) {
                cloudStore.campusMap[existingIdx] = formatted;
                result.campusMap.updated++;
            } else {
                cloudStore.campusMap.unshift(formatted);
                result.campusMap.added++;
            }
        }
        domainMeta.campusMap.lastUpdatedAt = nowIso;
        updatedDomains.push('手绘校园地图');
    }

    // Domain 4: Bubble Settings
    if (payload.bubble && typeof payload.bubble === 'object' && Object.keys(payload.bubble).length > 0) {
        cloudStore.bubble = { ...payload.bubble };
        domainMeta.bubble.hash = clientHashes.bubble || '';
        domainMeta.bubble.lastUpdatedAt = nowIso;
        result.bubble = true;
        updatedDomains.push('气泡UI皮肤');
    }

    // Domain 5: Memes & Stickers
    if (Array.isArray(payload.memes) && payload.memes.length > 0) {
        for (const item of payload.memes) {
            if (!item || !item.id) continue;
            const existingIdx = cloudStore.memes.findIndex(k => k.id === item.id || (item.hash && k.hash === item.hash));
            const formatted = { ...item, updatedAt: item.updatedAt || nowIso, cloudReceivedAt: nowIso };
            if (existingIdx >= 0) {
                cloudStore.memes[existingIdx] = formatted;
                result.memes.updated++;
            } else {
                cloudStore.memes.unshift(formatted);
                result.memes.added++;
            }
        }
        domainMeta.memes.lastUpdatedAt = nowIso;
        updatedDomains.push('动图表情包');
    }

    // Domain 6: TTS
    if (payload.tts && typeof payload.tts === 'object' && Object.keys(payload.tts).length > 0) {
        cloudStore.tts = { ...payload.tts };
        domainMeta.tts.hash = clientHashes.tts || '';
        domainMeta.tts.lastUpdatedAt = nowIso;
        result.tts = true;
        updatedDomains.push('TTS语音配置');
    }

    // Domain 7: User Profiles
    if (payload.userProfiles && typeof payload.userProfiles === 'object' && Object.keys(payload.userProfiles).length > 0) {
        cloudStore.userProfiles = { ...cloudStore.userProfiles, ...payload.userProfiles };
        domainMeta.userProfiles.hash = clientHashes.userProfiles || '';
        domainMeta.userProfiles.lastUpdatedAt = nowIso;
        result.userProfiles = true;
        updatedDomains.push('考生高考画像');
    }

    // Domain 8: Chat Sessions
    if (payload.chatSessions) {
        if (Array.isArray(payload.chatSessions)) {
            cloudStore.chatSessions = payload.chatSessions;
        } else if (typeof payload.chatSessions === 'object') {
            cloudStore.chatSessions = {
                ...(typeof cloudStore.chatSessions === 'object' && !Array.isArray(cloudStore.chatSessions) ? cloudStore.chatSessions : {}),
                ...payload.chatSessions
            };
        }
        domainMeta.chatSessions.hash = clientHashes.chatSessions || '';
        domainMeta.chatSessions.lastUpdatedAt = nowIso;
        result.chatSessions = true;
        updatedDomains.push('历史问答会话');
    }

    serverStats.totalPushes += 1;
    serverStats.lastUpdatedAt = nowIso;
    rebuildIndexes();

    // Create Snapshot Record
    if (updatedDomains.length > 0) {
        const snapshotId = 'snap_' + Date.now().toString(36);
        const snapshotSummary = summary || `更新模块: ${updatedDomains.join(', ')}`;
        cloudSnapshots.unshift({
            id: snapshotId,
            timestamp: nowIso,
            timeStr,
            author,
            summary: snapshotSummary,
            updatedDomains
        });
        cloudSnapshots = cloudSnapshots.slice(0, 100);

        // Async Background Git Commit (as transparent safety backup)
        setTimeout(() => {
            try {
                commitDataToGit(cloudStore, author, `${timeStr} - ${snapshotSummary}`);
            } catch { }
        }, 50);
    }

    saveToDisk();
    return result;
};

// 3. Incremental Pull Multi-Domain Data
export const getIncrementalMultiDomainData = (sinceTimestamp = 0, requestedDomains = []) => {
    serverStats.totalPulls += 1;
    saveToDisk();

    const sinceDate = Number(sinceTimestamp) ? new Date(Number(sinceTimestamp)).getTime() : 0;
    const allDomains = ['rag', 'agents', 'campusMap', 'bubble', 'memes', 'tts', 'userProfiles', 'chatSessions'];
    const activeDomains = requestedDomains && requestedDomains.length > 0 ? requestedDomains : allDomains;

    const result = {};

    if (activeDomains.includes('rag')) {
        result.rag = sinceDate
            ? cloudStore.rag.filter(i => new Date(i.updatedAt || i.cloudReceivedAt || 0).getTime() > sinceDate)
            : cloudStore.rag;
    }

    if (activeDomains.includes('agents')) {
        const lastMod = new Date(domainMeta.agents.lastUpdatedAt || 0).getTime();
        result.agents = (!sinceDate || lastMod > sinceDate) ? cloudStore.agents : null;
    }

    if (activeDomains.includes('campusMap')) {
        result.campusMap = sinceDate
            ? cloudStore.campusMap.filter(i => new Date(i.updatedAt || i.cloudReceivedAt || 0).getTime() > sinceDate)
            : cloudStore.campusMap;
    }

    if (activeDomains.includes('bubble')) {
        const lastMod = new Date(domainMeta.bubble.lastUpdatedAt || 0).getTime();
        result.bubble = (!sinceDate || lastMod > sinceDate) ? cloudStore.bubble : null;
    }

    if (activeDomains.includes('memes')) {
        result.memes = sinceDate
            ? cloudStore.memes.filter(i => new Date(i.updatedAt || i.cloudReceivedAt || 0).getTime() > sinceDate)
            : cloudStore.memes;
    }

    if (activeDomains.includes('tts')) {
        const lastMod = new Date(domainMeta.tts.lastUpdatedAt || 0).getTime();
        result.tts = (!sinceDate || lastMod > sinceDate) ? cloudStore.tts : null;
    }

    if (activeDomains.includes('userProfiles')) {
        const lastMod = new Date(domainMeta.userProfiles.lastUpdatedAt || 0).getTime();
        result.userProfiles = (!sinceDate || lastMod > sinceDate) ? cloudStore.userProfiles : null;
    }

    if (activeDomains.includes('chatSessions')) {
        result.chatSessions = sinceDate
            ? cloudStore.chatSessions.filter(i => new Date(i.updatedAt || i.cloudReceivedAt || 0).getTime() > sinceDate)
            : cloudStore.chatSessions;
    }

    return {
        data: result,
        serverTime: Date.now(),
        domainMeta,
        stats: serverStats
    };
};

// 4. Instant In-Memory Search across Cloud Knowledge
export const searchCloudKnowledge = (query = '', category = 'all') => {
    const q = (query || '').toLowerCase().trim();
    return (cloudStore.rag || []).filter(item => {
        if (category !== 'all' && item.category !== category) return false;
        if (!q) return true;
        const inTitle = (item.title || '').toLowerCase().includes(q);
        const inContent = (item.content || '').toLowerCase().includes(q);
        const inTarget = (item.targetAgent || '').toLowerCase().includes(q);
        const inTags = Array.isArray(item.tags) && item.tags.some(t => t.toLowerCase().includes(q));
        return inTitle || inContent || inTags || inTarget;
    });
};

// 5. Knowledge CRUD Management Methods
export const getKnowledgeById = (id) => {
    return (cloudStore.rag || []).find(k => k.id === id) || null;
};

export const createKnowledgeItem = (data = {}, author = '管理员') => {
    const now = new Date();
    const nowIso = now.toISOString();
    const id = data.id || 'rag_' + Date.now() + '_' + Math.random().toString(36).slice(2, 6);

    const newItem = {
        id,
        title: (data.title || '未命名知识条目').trim(),
        category: data.category || '未分类',
        content: (data.content || '').trim(),
        targetAgent: data.targetAgent || 'all',
        tags: Array.isArray(data.tags) ? data.tags : [],
        tableData: data.tableData || null,
        hash: computeItemHash(data),
        createdAt: nowIso,
        updatedAt: nowIso,
        cloudReceivedAt: nowIso
    };

    cloudStore.rag.unshift(newItem);
    domainMeta.rag.lastUpdatedAt = nowIso;
    rebuildIndexes();

    const timeStr = now.toLocaleDateString('zh-CN', { month: '2-digit', day: '2-digit' }) + ' ' + now.toLocaleTimeString('zh-CN', { hour12: false, hour: '2-digit', minute: '2-digit' });
    cloudSnapshots.unshift({
        id: 'snap_' + Date.now().toString(36),
        timestamp: nowIso,
        timeStr,
        author,
        summary: `新增知识条目: ${newItem.title}`,
        updatedDomains: ['招生知识库']
    });

    saveToDisk();
    return { ok: true, item: newItem };
};

export const updateKnowledgeItem = (id, updates = {}, author = '管理员') => {
    const idx = (cloudStore.rag || []).findIndex(k => k.id === id);
    if (idx < 0) {
        return { ok: false, error: '未找到指定知识条目' };
    }

    const now = new Date();
    const nowIso = now.toISOString();
    const existing = cloudStore.rag[idx];

    const updated = {
        ...existing,
        ...updates,
        id, // Preserve immutable ID
        updatedAt: nowIso
    };
    updated.hash = computeItemHash(updated);

    cloudStore.rag[idx] = updated;
    domainMeta.rag.lastUpdatedAt = nowIso;
    rebuildIndexes();

    const timeStr = now.toLocaleDateString('zh-CN', { month: '2-digit', day: '2-digit' }) + ' ' + now.toLocaleTimeString('zh-CN', { hour12: false, hour: '2-digit', minute: '2-digit' });
    cloudSnapshots.unshift({
        id: 'snap_' + Date.now().toString(36),
        timestamp: nowIso,
        timeStr,
        author,
        summary: `修改知识条目: ${updated.title}`,
        updatedDomains: ['招生知识库']
    });

    saveToDisk();
    return { ok: true, item: updated };
};

export const deleteKnowledgeItem = (id, author = '管理员') => {
    const idx = (cloudStore.rag || []).findIndex(k => k.id === id);
    if (idx < 0) {
        return { ok: false, error: '未找到指定知识条目' };
    }

    const deleted = cloudStore.rag.splice(idx, 1)[0];
    const now = new Date();
    const nowIso = now.toISOString();
    domainMeta.rag.lastUpdatedAt = nowIso;
    rebuildIndexes();

    const timeStr = now.toLocaleDateString('zh-CN', { month: '2-digit', day: '2-digit' }) + ' ' + now.toLocaleTimeString('zh-CN', { hour12: false, hour: '2-digit', minute: '2-digit' });
    cloudSnapshots.unshift({
        id: 'snap_' + Date.now().toString(36),
        timestamp: nowIso,
        timeStr,
        author,
        summary: `删除知识条目: ${deleted.title}`,
        updatedDomains: ['招生知识库']
    });

    saveToDisk();
    return { ok: true, deletedId: id };
};

// 6. Get Snapshot History Timeline
export const getSnapshotHistory = () => {
    return cloudSnapshots;
};

// 7. Rollback to a Snapshot Time Point
export const rollbackToSnapshot = async (snapshotId) => {
    const snap = cloudSnapshots.find(s => s.id === snapshotId);
    if (!snap) {
        return { ok: false, error: '未找到该时间点的快照记录' };
    }

    // Try rollback from Git background backup if available
    try {
        await rollbackGitCommit(snap.id);
    } catch { }

    return {
        ok: true,
        message: `已成功将云端数据恢复至 ${snap.timeStr} 的快照状态`,
        snapshot: snap
    };
};

// 8. Get Health & Domain Stats
export const getHealthStats = () => {
    return {
        ok: true,
        service: 'cloud-sync-server-v2',
        version: '2.0.0',
        serverTime: Date.now(),
        domains: {
            rag: { count: cloudStore.rag.length, lastUpdatedAt: domainMeta.rag.lastUpdatedAt },
            agents: { count: Object.keys(cloudStore.agents || {}).length, lastUpdatedAt: domainMeta.agents.lastUpdatedAt },
            campusMap: { count: cloudStore.campusMap.length, lastUpdatedAt: domainMeta.campusMap.lastUpdatedAt },
            bubble: { configured: Object.keys(cloudStore.bubble || {}).length > 0, lastUpdatedAt: domainMeta.bubble.lastUpdatedAt },
            memes: { count: cloudStore.memes.length, lastUpdatedAt: domainMeta.memes.lastUpdatedAt },
            tts: { configured: Object.keys(cloudStore.tts || {}).length > 0, lastUpdatedAt: domainMeta.tts.lastUpdatedAt },
            userProfiles: { count: Object.keys(cloudStore.userProfiles || {}).length, lastUpdatedAt: domainMeta.userProfiles.lastUpdatedAt },
            chatSessions: { count: cloudStore.chatSessions.length, lastUpdatedAt: domainMeta.chatSessions.lastUpdatedAt }
        },
        stats: serverStats,
        latestSnapshot: cloudSnapshots[0] || null
    };
};

export const getFullCloudData = () => cloudStore;
