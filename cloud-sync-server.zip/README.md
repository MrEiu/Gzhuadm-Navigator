# ☁️ Gzadm Navigator Cloud Knowledge Sync Microservice

> **独立的云端知识库集中存储与多端增量同步微服务**  
> 监听 `0.0.0.0:3800`，内置零配置持久化存储与 SHA-256 智能指纹批量去重引擎。

---

## 🚀 部署与运行 (Deployment)

### 1. 本地或云服务器直接运行
```bash
cd cloud-sync-server

# 安装依赖
npm install

# 复制配置文件 (可选)
cp .env.example .env

# 启动服务 (监听 0.0.0.0:3800)
npm start
```

### 2. 使用 PM2 生产环境守护运行
```bash
npm install -g pm2
pm2 start server.mjs --name "gzadm-cloud-sync"
pm2 save
```

### 3. Docker 容器化运行
```bash
# 启动容器并映射端口
docker run -d \
  -p 3800:3800 \
  -v $(pwd)/data:/app/data \
  -e PORT=3800 \
  -e HOST=0.0.0.0 \
  --name gzadm-cloud-sync \
  node:20-alpine sh -c "cd /app && npm install && npm start"
```

---

## 📡 API 接口清单

| 方法 | 路径 | 描述 |
| :--- | :--- | :--- |
| `GET` | `/api/health` | 服务健康探活，返回云端知识总条数与最后更新时间 |
| `POST` | `/api/sync/check-hashes` | **智能去重第一步**：$O(1)$ 批量比对本地指纹，返回云端缺失的 hash 列表 |
| `POST` | `/api/sync/push` | **智能去重第二步**：批量写入本地上传的缺失知识条目 |
| `GET` | `/api/sync/pull?since={timestamp}` | **增量拉取**：按时间戳仅拉取上次同步后云端新增的数据 |
| `GET` | `/api/sync/stats` | 获取云端统计数据（总知识数、总拉取次数、总推送次数） |

---

## 🔐 安全与鉴权
如需保护云端数据不被随意读写，可在 `.env` 中设置：
```env
SYNC_SECRET=your_custom_secret_key
```
客户端同步请求时，在 HTTP Header 中附带 `X-Sync-Secret: your_custom_secret_key` 即可完成安全鉴权。
