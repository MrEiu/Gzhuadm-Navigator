import fs from 'fs';
import path from 'path';
import { execFile } from 'child_process';
import { promisify } from 'util';
import { fileURLToPath } from 'url';

const execFileAsync = promisify(execFile);
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Dedicated Git Data Repository Directory
export const repoDir = path.join(__dirname, 'data_repo');

// Execute git command inside the repo directory
export const runGit = async (args = []) => {
    try {
        const { stdout, stderr } = await execFileAsync('git', args, {
            cwd: repoDir,
            windowsHide: true,
            maxBuffer: 50 * 1024 * 1024
        });
        return { ok: true, stdout: stdout.trim(), stderr: stderr.trim() };
    } catch (err) {
        return { ok: false, error: err.message, stderr: err.stderr?.trim() || '' };
    }
};

// Seed templates for 8 domain files
const DEFAULT_FILES = {
    'rag_knowledge.json': [],
    'agents_config.json': {
        dr: { key: 'dr', name: 'Dr. Elena', title: '首席招生咨询顾问', bubbleColor: '#8b5cf6', voice: 'zh-CN-XiaoxiaoNeural' },
        dorm: { key: 'dorm', name: '宿管张阿姨', title: '宿舍生活与安全管家', bubbleColor: '#f97316', voice: 'zh-CN-XiaoyiNeural' },
        counselor: { key: 'counselor', name: '辅导员李导', title: '本科生年级辅导员', bubbleColor: '#2563eb', voice: 'zh-CN-YunjianNeural' },
        senior_boy: { key: 'senior_boy', name: '学长浩哥', title: '计科大四学长 / 校园生活指南', bubbleColor: '#10b981', voice: 'zh-CN-YunxiNeural' },
        senior_girl: { key: 'senior_girl', name: '学姐丽丽', title: '校园文旅探店 / 社团达人', bubbleColor: '#ec4899', voice: 'zh-CN-XiaohanNeural' }
    },
    'campus_map.json': [],
    'bubble_settings.json': {
        themeId: 'antdesign_filled',
        borderRadius: 20,
        accentBarWidth: 0,
        showTail: false,
        showActions: true,
        showThinkingBox: true
    },
    'custom_memes.json': [],
    'tts_config.json': {
        engine: 'msedge',
        defaultVoice: 'zh-CN-XiaoyiNeural',
        rate: 1.0,
        pitch: 1.0
    },
    'user_profiles.json': {},
    'chat_sessions.json': []
};

// Initialize Git Data Repository
export const initGitRepo = async () => {
    if (!fs.existsSync(repoDir)) {
        fs.mkdirSync(repoDir, { recursive: true });
    }

    // 1. Check if .git exists
    const gitPath = path.join(repoDir, '.git');
    if (!fs.existsSync(gitPath)) {
        console.log(`📦 [Git Engine] Initializing Git data repository in ${repoDir}...`);
        await execFileAsync('git', ['init'], { cwd: repoDir });
        await execFileAsync('git', ['config', 'user.name', 'Gzadm Cloud Master'], { cwd: repoDir });
        await execFileAsync('git', ['config', 'user.email', 'cloud-master@gzhu.edu.cn'], { cwd: repoDir });

        // Write initial seed files
        for (const [filename, content] of Object.entries(DEFAULT_FILES)) {
            const filePath = path.join(repoDir, filename);
            if (!fs.existsSync(filePath)) {
                fs.writeFileSync(filePath, JSON.stringify(content, null, 2), 'utf8');
            }
        }

        await runGit(['add', '.']);
        await runGit(['commit', '-m', 'Initial commit: Seed 8-domain Gzadm data architecture']);
        console.log(`✅ [Git Engine Ready] Git repository initialized successfully!`);
    } else {
        console.log(`✅ [Git Engine Ready] Existing Git data repository loaded from ${repoDir}`);
    }
};

// 1. Commit and Record New Version
export const commitDataToGit = async (payload = {}, author = 'Admin', commitMsg = '') => {
    const domainToFile = {
        rag: 'rag_knowledge.json',
        agents: 'agents_config.json',
        campusMap: 'campus_map.json',
        bubble: 'bubble_settings.json',
        memes: 'custom_memes.json',
        tts: 'tts_config.json',
        userProfiles: 'user_profiles.json',
        chatSessions: 'chat_sessions.json'
    };

    const changedFiles = [];

    // Write updated payload files to data_repo/
    for (const [domain, filename] of Object.entries(domainToFile)) {
        if (payload[domain] !== undefined && payload[domain] !== null) {
            const filePath = path.join(repoDir, filename);
            fs.writeFileSync(filePath, JSON.stringify(payload[domain], null, 2), 'utf8');
            changedFiles.push(filename);
        }
    }

    if (changedFiles.length === 0) {
        return { ok: true, committed: false, message: 'No data files were changed' };
    }

    // Git add
    await runGit(['add', ...changedFiles]);

    // Check status
    const statusRes = await runGit(['status', '--porcelain']);
    if (!statusRes.stdout) {
        return { ok: true, committed: false, message: 'Data content is identical to latest Git commit' };
    }

    // Format commit message
    const message = commitMsg || `Sync update: ${changedFiles.join(', ')} by ${author}`;
    const safeAuthorEmail = (author || 'admin').toLowerCase().replace(/[^a-z0-9]/g, '') || 'admin';
    const authorParam = `${author || 'Admin'} <${safeAuthorEmail}@gzhu.edu.cn>`;

    const commitRes = await runGit(['commit', `--author=${authorParam}`, '-m', message]);
    if (!commitRes.ok) {
        console.warn('⚠️ [Git Commit Warning]:', commitRes.error || commitRes.stderr);
        return { ok: false, error: commitRes.error || commitRes.stderr };
    }

    // Get current commit info
    const headRes = await runGit(['rev-parse', '--short', 'HEAD']);
    const fullHashRes = await runGit(['rev-parse', 'HEAD']);

    return {
        ok: true,
        committed: true,
        commitHash: headRes.stdout,
        fullHash: fullHashRes.stdout,
        message,
        author,
        changedFiles,
        timestamp: new Date().toISOString()
    };
};

// 2. Get Commit History Timeline
export const getGitHistory = async (limit = 50) => {
    // Format: hash%x1fshort%x1fauthor%x1fdate%x1fmessage
    const logRes = await runGit([
        'log',
        `-n${limit}`,
        '--pretty=format:%H%x1f%h%x1f%an%x1f%ad%x1f%s',
        '--date=iso'
    ]);

    if (!logRes.ok || !logRes.stdout) {
        return [];
    }

    const lines = logRes.stdout.split('\n');
    const commits = [];

    for (const line of lines) {
        const parts = line.split('\x1f');
        if (parts.length >= 5) {
            commits.push({
                fullHash: parts[0],
                shortHash: parts[1],
                author: parts[2],
                date: parts[3],
                message: parts[4]
            });
        }
    }

    return commits;
};

// 3. Get Diff of a specific commit or between commits
export const getGitDiff = async (commitHash = 'HEAD') => {
    const diffRes = await runGit(['show', '--stat', '--patch', commitHash]);
    if (!diffRes.ok) {
        return { ok: false, error: diffRes.error || diffRes.stderr };
    }
    return {
        ok: true,
        commitHash,
        diff: diffRes.stdout
    };
};

// 4. Rollback to a specific commit
export const rollbackGitCommit = async (targetCommitHash, author = 'Admin') => {
    if (!targetCommitHash) {
        return { ok: false, error: 'Target commit hash is required' };
    }

    // Checkout files from target commit
    const checkoutRes = await runGit(['checkout', targetCommitHash, '--', '.']);
    if (!checkoutRes.ok) {
        return { ok: false, error: `Git checkout failed: ${checkoutRes.error || checkoutRes.stderr}` };
    }

    // Commit the rollback as a new commit
    const commitRes = await commitDataToGit(
        getAllRepoData(),
        author,
        `⏪ Rollback to commit ${targetCommitHash.slice(0, 7)}`
    );

    return {
        ok: true,
        message: `Successfully restored and committed data to version ${targetCommitHash.slice(0, 7)}`,
        rollbackCommit: commitRes
    };
};

// 5. Read all 8-domain data from repoDir
export const getAllRepoData = () => {
    const data = {};
    const domainToFile = {
        rag: 'rag_knowledge.json',
        agents: 'agents_config.json',
        campusMap: 'campus_map.json',
        bubble: 'bubble_settings.json',
        memes: 'custom_memes.json',
        tts: 'tts_config.json',
        userProfiles: 'user_profiles.json',
        chatSessions: 'chat_sessions.json'
    };

    for (const [domain, filename] of Object.entries(domainToFile)) {
        const filePath = path.join(repoDir, filename);
        if (fs.existsSync(filePath)) {
            try {
                data[domain] = JSON.parse(fs.readFileSync(filePath, 'utf8'));
            } catch {
                data[domain] = DEFAULT_FILES[filename];
            }
        } else {
            data[domain] = DEFAULT_FILES[filename];
        }
    }

    return data;
};
