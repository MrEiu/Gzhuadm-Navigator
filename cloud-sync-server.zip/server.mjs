import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import {
    initCloudDb,
    checkMultiDomainHashes,
    upsertMultiDomainData,
    getIncrementalMultiDomainData,
    getHealthStats,
    searchCloudKnowledge,
    getKnowledgeById,
    createKnowledgeItem,
    updateKnowledgeItem,
    deleteKnowledgeItem,
    getSnapshotHistory,
    rollbackToSnapshot,
    getFullCloudData
} from './db.mjs';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Load .env from cloud-sync-server/ or root
dotenv.config({ path: path.join(__dirname, '.env') });
if (!process.env.SYNC_SECRET) {
    dotenv.config({ path: path.join(__dirname, '..', '.env') });
}

const app = express();
const PORT = process.env.PORT || 3800;
const HOST = process.env.HOST || '0.0.0.0';
const SYNC_SECRET = process.env.SYNC_SECRET || '';

// Middleware
app.use(cors({ origin: '*' }));
app.use(express.json({ limit: '100mb' }));
app.use(express.urlencoded({ extended: true, limit: '100mb' }));

// Serve Cloud Web Admin Console static files
app.use(express.static(path.join(__dirname, 'public')));

// Initialize Storage
await initCloudDb();

// Secret Key Verification Middleware
const verifySecret = (req, res, next) => {
    if (!SYNC_SECRET) return next();

    const clientSecret = req.headers['x-sync-secret'] || req.query.secret || req.body?.secret;
    if (clientSecret !== SYNC_SECRET) {
        return res.status(401).json({
            ok: false,
            error: 'Authentication failed: Invalid sync secret key (X-Sync-Secret header mismatch)'
        });
    }
    next();
};

// 1. Health & Heartbeat Probe
app.get('/api/health', (_req, res) => {
    const health = getHealthStats();
    res.json({
        ...health,
        requiresSecret: Boolean(SYNC_SECRET)
    });
});

// 2. Multi-Domain Batch Hash Verification
app.post('/api/sync/check-hashes', verifySecret, (req, res) => {
    const body = req.body || {};
    const hashesInput = body.hashes && typeof body.hashes === 'object' && !Array.isArray(body.hashes)
        ? body.hashes
        : { rag: Array.isArray(body.hashes) ? body.hashes : [] };

    const missing = checkMultiDomainHashes(hashesInput);

    res.json({
        ok: true,
        missing,
        missingHashes: missing.rag || []
    });
});

// 3. Multi-Domain Push (High-Speed Ingestion + Background Snapshot)
app.post('/api/sync/push', verifySecret, (req, res) => {
    const body = req.body || {};
    const payload = body.payload || (body.items ? { rag: body.items } : {});
    const hashes = body.hashes || {};
    const author = body.author || '管理员';
    const summary = body.commitMessage || body.message || '';

    const result = upsertMultiDomainData(payload, hashes, author, summary);

    res.json({
        ok: true,
        message: '数据已成功同步至云端中枢数据库并生成快照',
        result,
        addedCount: result.rag?.added || 0,
        updatedCount: result.rag?.updated || 0
    });
});

// 4. Multi-Domain Incremental Pull
app.get('/api/sync/pull', verifySecret, (req, res) => {
    const since = req.query.since || 0;
    const domainsQuery = req.query.domains ? req.query.domains.split(',') : [];

    const result = getIncrementalMultiDomainData(since, domainsQuery);

    res.json({
        ok: true,
        sinceQuery: since,
        domains: domainsQuery,
        ...result,
        items: result.data.rag || []
    });
});

// 5. Cloud Knowledge Management APIs (Open for Web Console Read)
app.get('/api/knowledge/search', (req, res) => {
    const { q, category } = req.query || {};
    const items = searchCloudKnowledge(q || '', category || 'all');
    res.json({ ok: true, total: items.length, items });
});

app.get('/api/knowledge/detail', (req, res) => {
    const { id } = req.query || {};
    const item = getKnowledgeById(id);
    if (!item) return res.status(404).json({ ok: false, error: '条目不存在' });
    res.json({ ok: true, item });
});

app.post('/api/knowledge/create', verifySecret, (req, res) => {
    const { item, author } = req.body || {};
    const result = createKnowledgeItem(item || {}, author || '云端管理员');
    res.json(result);
});

app.put('/api/knowledge/update', verifySecret, (req, res) => {
    const { id, updates, author } = req.body || {};
    const result = updateKnowledgeItem(id, updates || {}, author || '云端管理员');
    res.json(result);
});

app.delete('/api/knowledge/delete', verifySecret, (req, res) => {
    const { id, author } = req.body || {};
    const result = deleteKnowledgeItem(id, author || '云端管理员');
    res.json(result);
});

// 6. Snapshot History Timeline (Open for Web Console Read)
app.get('/api/snapshots/history', (_req, res) => {
    res.json({ ok: true, snapshots: getSnapshotHistory() });
});

// 7. Rollback to Snapshot
app.post('/api/snapshots/rollback', verifySecret, async (req, res) => {
    const { snapshotId } = req.body || {};
    const result = await rollbackToSnapshot(snapshotId);
    res.json(result);
});

// 8. Full Cloud Data Export (Open for Web Console Read)
app.get('/api/cloud/data', (_req, res) => {
    res.json({ ok: true, data: getFullCloudData() });
});

// 9. Statistics Endpoint
app.get('/api/sync/stats', (_req, res) => {
    res.json(getHealthStats());
});

app.listen(Number(PORT), HOST, () => {
    console.log(`\n======================================================`);
    console.log(`☁️  Gzadm Navigator Cloud Master Server v2.0 Ready!`);
    console.log(`👉 Web Console:  http://${HOST}:${PORT} (Open in browser)`);
    console.log(`🔑 Secret Auth:  ${SYNC_SECRET ? 'ENABLED (Protected by X-Sync-Secret)' : 'DISABLED (Public Open)'}`);
    console.log(`📦 Architecture: High-Performance Database + Knowledge Detail Management`);
    console.log(`======================================================\n`);
});
